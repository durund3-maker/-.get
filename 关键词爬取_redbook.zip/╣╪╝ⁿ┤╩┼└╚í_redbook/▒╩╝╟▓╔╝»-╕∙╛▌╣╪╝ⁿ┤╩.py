# -*- coding: utf-8 -*-
"""
小红书关键词采集（修复网络代理问题 + 稳健重试）
- 显式禁用系统代理，避免 ProxyError
- 可选自定义代理
- 加入重试/退避/抖动
- execjs 失败自动回退 DummySign（仅用于不报错，真实签名仍建议使用你的 xhs.js）

使用步骤：
1) 建议先把 base_headers['cookie'] 替换为你浏览器复制的有效 Cookie。
2) 若你有 xhs.js 的签名实现，保持文件在同目录；没有就用 DummySign，但接口可能返回 success=False。
3) 若确实需要走代理，把 USE_CUSTOM_PROXY = True，并配置 CUSTOM_PROXIES。
"""

import random
import time
import requests
import json
import csv
import os
import logging

# ========== 日志 ==========
logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s [%(levelname)s] %(message)s"
)

note_count = 0

# ========== 代理相关配置 ==========
# 显式禁用系统/环境代理，防止 requests 读到系统里的无效代理
DISABLE_SYSTEM_PROXY = True

# 如需自定义代理（公司出口/本地代理），置 True 并填写下方 CUSTOM_PROXIES
USE_CUSTOM_PROXY = False
CUSTOM_PROXIES = {
    # 示例：
    # "http": "http://user:pass@127.0.0.1:7890",
    # "https": "http://user:pass@127.0.0.1:7890"
}

# ========== 轻微反爬：超时/抖动/重试 ==========
REQUEST_TIMEOUT = 12
MAX_RETRIES = 3
BACKOFF_BASE = 1.2          # 指数退避基数
JITTER_RANGE = (0.3, 0.9)   # 每次请求前抖动

# ========== execjs（签名） ==========
xhs_sign_obj = None

class DummySign:
    """占位签名器，返回空的签名头。真实环境请用 xhs.js 实现。"""
    def call(self, method, uri=None, data=None, cookie=None):
        if method == 'searchId':
            return str(int(time.time() * 1000)) + str(random.randint(1000, 9999))
        elif method == 'sign':
            return {}
        return {}

def load_sign():
    global xhs_sign_obj
    try:
        import execjs  # 仅在需要时导入
        js_path = os.path.join(os.path.dirname(__file__), 'static', 'xhs.js')
        with open(js_path, 'r', encoding='utf-8') as f:
            xhs_sign_obj = execjs.compile(f.read())
        logging.info("签名模块加载成功：static/xhs.js")
    except Exception as e:
        xhs_sign_obj = DummySign()
        logging.warning("JS 逆向失败：%s  -> 使用 DummySign（接口可能要求真实签名）", e)

# ========== 映射表 ==========
note_type_dict = {
    "全部": 0,
    "视频": 1,
    "图文": 2
}

sort_type_dict = {
    "综合": "general",
    "最新": "time_descending",
    "最多点赞": "popularity_descending",
    "最多评论": "comment_descending",
    "最多收藏": "collect_descending"
}

base_headers = {
    "accept": "application/json, text/plain, */*",
    "accept-language": "zh-CN,zh;q=0.9,en;q=0.8",
    "cache-control": "no-cache",
    "content-type": "application/json;charset=UTF-8",
    "dnt": "1",
    "origin": "https://www.xiaohongshu.com",
    "pragma": "no-cache",
    "priority": "u=1, i",
    "referer": "https://www.xiaohongshu.com/",
    "sec-ch-ua": '"Chromium";v="128", "Not;A=Brand";v="24", "Google Chrome";v="128"',
    "sec-ch-ua-mobile": "?0",
    "sec-ch-ua-platform": '"Windows"',
    "sec-fetch-dest": "empty",
    "sec-fetch-mode": "cors",
    "sec-fetch-site": "same-site",
    # !!! 这里替换为你的真实 Cookie !!!
    "cookie": "abRequestId=0696e4f5-a065-560c-b15a-cc119a67cefa; a1=199046c9a18vn6bmgc3annmam9fvv301q7u9jm1q350000142666; webId=6d7ccf045772ea1c8cf5f8054ad5d8bf; gid=yjj84KSDJyAqyjj84KSj0W6yyYhIKD6kSq0I7AqI606jij28hhq8yV888y4JKKK8qW8j2fi8; webBuild=4.79.0; acw_tc=0a00dddd17570001748326823e24a17e85227c3c2681a77ffb9f9b04e1088a; xsecappid=xhs-pc-web; loadts=1757000174574; websectiga=984412fef754c018e472127b8effd174be8a5d51061c991aadd200c69a2801d6; sec_poison_id=0f31884e-be5f-4fce-8442-319dff53497d; web_session=040069b20f6c892f2bf447fa8c3a4bf3dcac65; unread={%22ub%22:%2268b715f9000000001d005ffe%22%2C%22ue%22:%2268b40283000000001d01a175%22%2C%22uc%22:27}",
    "user-agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/139.0.0.0 Safari/537.36"
}

# ========== requests 会话 ==========
session = requests.Session()
if DISABLE_SYSTEM_PROXY:
    # 不读取系统/环境代理（核心修复点：避免走到不存在的代理）
    session.trust_env = False

def _proxies_for_request():
    """返回本次请求的 proxies 配置。"""
    if USE_CUSTOM_PROXY:
        return CUSTOM_PROXIES
    # 显式传入空 dict，确保不走任何代理
    return {}

def _sleep_with_jitter():
    time.sleep(random.uniform(*JITTER_RANGE))

# ========== 通用请求（带重试） ==========
def _request_with_retry(method, url, **kwargs):
    for attempt in range(1, MAX_RETRIES + 1):
        try:
            _sleep_with_jitter()
            resp = session.request(method, url, timeout=REQUEST_TIMEOUT, proxies=_proxies_for_request(), **kwargs)
            return resp
        except requests.RequestException as e:
            if attempt >= MAX_RETRIES:
                raise
            backoff = BACKOFF_BASE ** attempt + random.random()
            logging.warning("网络异常(%s)，第 %d/%d 次重试，休眠 %.1fs", e, attempt, MAX_RETRIES, backoff)
            time.sleep(backoff)

# ========== API 封装 ==========
def post_request(url, uri, data):
    try:
        sign_header = xhs_sign_obj.call('sign', uri, data, base_headers.get('cookie', ''))
    except Exception as e:
        logging.error("调用签名失败：%s", e)
        return {"success": False}

    headers = {**base_headers, **(sign_header or {})}
    payload = json.dumps(data, separators=(',', ':'), ensure_ascii=False).encode('utf-8')

    try:
        resp = _request_with_retry("POST", url, headers=headers, data=payload)
        # 若代理不可达/系统代理被误用，会在上面就抛错并被捕获
        js = resp.json()
        if js.get('success') is False:
            logging.warning("接口返回 success=False（可能是 Cookie 失效/签名不正确/频率限制）")
            return {"success": False}
        return {"success": True, "data": js.get("data")}
    except requests.RequestException as e:
        logging.error("请求失败：%s", e)
        return {"success": False}
    except ValueError:
        logging.error("响应不是 JSON，可能被风控或返回了 HTML 验证页。HTTP %s", resp.status_code if 'resp' in locals() else '?')
        return {"success": False}

# ========== 工具函数 ==========
def get_time_ms_to_date(ctime_ms):
    try:
        t = int(ctime_ms) // 1000
        return time.strftime("%Y.%m.%d", time.localtime(t))
    except Exception:
        return ""

def save_note_row(note_data, note_id, xsec_token, writer, flush_file=None):
    note_card = note_data.get('note_card', {}) or {}
    interact = note_card.get('interact_info', {}) or {}
    user = note_card.get('user', {}) or {}
    tag_list = ["#" + (t.get('name') or '') for t in (note_card.get('tag_list') or [])]

    row = {
        "笔记标题": (note_card.get('title') or '').strip(),
        "笔记链接": f"https://www.xiaohongshu.com/explore/{note_id}?xsec_token={xsec_token}&xsec_source=pc_feed",
        "用户ID": (user.get('user_id') or '').strip(),
        "用户名": (user.get('nickname') or '').strip(),
        "头像链接": (user.get('avatar') or '').strip(),
        "IP属地": note_card.get('ip_location', '未知'),
        "笔记发布时间": get_time_ms_to_date(note_card.get('time', 0)),
        "笔记收藏数量": interact.get('collected_count', 0),
        "笔记评论数量": interact.get('comment_count', 0),
        "笔记点赞数量": interact.get('liked_count', 0),
        "笔记转发数量": interact.get('share_count', 0),
        "笔记标签": " ".join(tag_list),
        "笔记内容": (note_card.get('desc') or '').replace("\n", "").strip()
    }

    global note_count
    note_count += 1

    logging.info("采集 #%d | 标题:%s | 点赞:%s | 评论:%s",
                 note_count, row["笔记标题"], row["笔记点赞数量"], row["笔记评论数量"])
    writer.writerow(row)

    if flush_file:
        try:
            flush_file.flush()
            os.fsync(flush_file.fileno())
        except Exception:
            pass

def get_note_info(source_note_id, xsec_token, writer, flush_file=None):
    note_url = 'https://edith.xiaohongshu.com/api/sns/web/v1/feed'
    data = {
        "source_note_id": source_note_id,
        "image_scenes": ["jpg", "webp", "avif"],
        "extra": {"need_body_topic": "1"},
        "xsec_token": xsec_token,
        "xsec_source": "pc_search"
    }
    resp = post_request(note_url, uri='/api/sns/web/v1/feed', data=data)
    if not resp.get('success'):
        return False
    items = (resp['data'] or {}).get('items') or []
    if not items:
        return False
    note_data = items[0]
    save_note_row(note_data, source_note_id, xsec_token, writer, flush_file)
    return True

def keyword_search(keyword, note_type, sort_type, filter_note_time, writer, flush_file=None):
    """
    filter_note_time：小红书这块常见是 ["不限"] / ["一天内"] / ["一周内"] / ["半年内"]
    传参保持为「列表」更保险。
    """
    search_url = "https://edith.xiaohongshu.com/api/sns/web/v1/search/notes"
    page = 1
    search_id = xhs_sign_obj.call('searchId')

    while True:
        filters = [
            {"tags": [sort_type_dict[sort_type]], "type": "sort_type"},
            {"tags": ["不限"], "type": "filter_note_type"},
            {"tags": [filter_note_time], "type": "filter_note_time"},
            {"tags": ["不限"], "type": "filter_note_range"},
            {"tags": ["不限"], "type": "filter_pos_distance"}
        ]
        data = {
            "ext_flags": [],
            "filters": filters,
            "geo": "",
            "image_formats": ["jpg", "webp", "avif"],
            "keyword": keyword,
            "note_type": note_type_dict[note_type],
            "page": page,
            "page_size": 20,
            "search_id": search_id,
            "sort": sort_type_dict[sort_type]
        }

        resp = post_request(search_url, uri='/api/sns/web/v1/search/notes', data=data)
        if not resp.get('success'):
            logging.warning("搜索接口返回 success=False 或请求失败，停止。")
            return

        data_block = resp.get('data') or {}
        items = data_block.get('items') or []
        if not items:
            logging.info("没有更多搜索结果，结束。")
            return

        logging.info("请求成功：关键词=%s | 第 %d 页 | items=%d", keyword, page, len(items))

        for note in items:
            if note.get('model_type') != "note":
                continue
            note_id = note.get('id')
            xsec_token = note.get('xsec_token')
            if not note_id or not xsec_token:
                continue
            # 轻微延时
            time.sleep(random.uniform(0.5, 1.8))
            ok = get_note_info(note_id, xsec_token, writer, flush_file)
            if not ok:
                logging.warning("获取笔记详情失败: note_id=%s", note_id)
                # 不立刻 return，继续其他笔记
                continue

        if not data_block.get('has_more'):
            logging.info("has_more=False，结束。")
            return

        page += 1

# ========== 主函数 ==========
def main():
    load_sign()

    # 你的查询参数
    keyword = '开题报告'
    note_type = '图文'       # 全部 / 图文 / 视频
    sort_type = '最新'       # 综合 / 最新 / 最多点赞 / 最多评论 / 最多收藏
    filter_note_time = '一天内'  # 不限 / 一天内 / 一周内 / 半年内

    # 输出 CSV
    filename = f"{keyword}_{note_type}_{sort_type}_{filter_note_time}.csv"
    header = ["笔记标题", "笔记链接", "用户ID", "用户名", "头像链接", "IP属地",
              "笔记发布时间", "笔记收藏数量", "笔记评论数量", "笔记点赞数量",
              "笔记转发数量", "笔记标签", "笔记内容"]

    logging.info("输出文件: %s", filename)

    with open(filename, "w", encoding="utf-8-sig", newline="") as f:
        writer = csv.DictWriter(f, header)
        writer.writeheader()

        # 运行搜索
        keyword_search(keyword, note_type, sort_type, filter_note_time, writer, flush_file=f)

    logging.info("================爬取完毕================")
    logging.info("共爬取笔记数量：%d", note_count)

if __name__ == "__main__":
    # 运行前的提示
    if not base_headers.get("cookie"):
        logging.warning("提示：base_headers['cookie'] 为空。很多接口需要登录态 Cookie，否则可能 success=False。")
    main()
